name = "MainShortcuts2"
version = "2.2.0"
