name="MainShortcuts2"
version="2.6.2"