name = "MainShortcuts2"
version = "2.5.1"
