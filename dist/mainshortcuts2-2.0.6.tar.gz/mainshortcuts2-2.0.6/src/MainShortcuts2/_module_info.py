name = "MainShortcuts2"
version = "2.0.6"
