def import_example():
  print("from MainShortcuts2 import ms")
  print("exec(ms.import_code)")
