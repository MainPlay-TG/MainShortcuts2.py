name = "MainShortcuts2"
version = "2.4.13"
