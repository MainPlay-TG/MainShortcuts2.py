name = "MainShortcuts2"
version = "2.3.3"
