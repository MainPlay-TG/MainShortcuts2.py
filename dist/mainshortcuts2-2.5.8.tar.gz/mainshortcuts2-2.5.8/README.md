# MainShortcuts2
## Описание
Сокращение и улучшение функций
## Установка
Для установки через `pip` используйте
```bash
python3 -m pip install -U MainShortcuts2
```
## Использование
Импорт модуля
```python
from MainShortcuts2 import ms
```
Встроенная информация о модуле
```python
ms.version -> str # Версия модуля
```
-# README в разработке, это оказалось сложнее, чем писать сам модуль