name = "MainShortcuts2"
version = "2.1.2"
