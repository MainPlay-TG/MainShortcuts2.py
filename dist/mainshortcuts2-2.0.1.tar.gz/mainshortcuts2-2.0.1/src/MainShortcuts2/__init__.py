"""Упрощение и сокращение вашего кода благодаря этой библиотеке
Разработчик: MainPlay TG
https://t.me/MainPlayCh"""
__all__ = ["ms", "MS2"]
__scripts__ = ["ms2-import_example"]
from ._module_info import version as __version__
# 2.0.0
from .core import MS2
ms = MS2()
